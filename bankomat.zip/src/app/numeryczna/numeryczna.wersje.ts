export const wersja_jezyk: Array<string> = 
[
  'skasuj',
  'delete',
  'löschen',
  'effacer'
]