interface teksty
{
  witaj: string;
  dyspozycje: string
}

export const wersja_jezyk: Array<teksty> = 
[
  {witaj: 'Witaj ', dyspozycje: 'Wybierz dyspozycje'},
  {witaj: 'Hello ', dyspozycje: 'Select an instruction'},
  {witaj: 'Hallo ', dyspozycje: 'Anweisung auswählen'},
  {witaj: 'Bonjour ', dyspozycje: 'Sélectionnez une instruction'}
]